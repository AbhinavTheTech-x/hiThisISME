import * as anchor from '@coral-xyz/anchor';
import { Program, web3, AnchorProvider, BN } from '@coral-xyz/anchor';
import { SolanaFarm } from '../target/types/solana_farm';
import { SOLANA_FARM_KEY, SOLANA_FARM_USER_PDA, SOLANA_FARM_VAULT, DEV_KEY } from '../config';

export const delay = (ms: number) => new Promise((res) => setTimeout(res, ms));

export const getDevKeyPair = () => {
  const devSecret = anchor.utils.bytes.bs58.decode(DEV_KEY);
  return anchor.web3.Keypair.fromSecretKey(devSecret);
};

export const getSolanaFarmKeyPair = () => {
  const solanaFarmSecret = anchor.utils.bytes.bs58.decode(SOLANA_FARM_KEY);
  return anchor.web3.Keypair.fromSecretKey(solanaFarmSecret);
};

export const getAccounts = () => {
  return {
    bob: web3.Keypair.generate(),
    alice: web3.Keypair.generate(),
    referral: web3.Keypair.generate()
  };
};

export const getPDA = (programId: web3.PublicKey, seed: string, pubKey?: web3.PublicKey) => {
  let seedBuffer = pubKey ? [Buffer.from(seed), pubKey.toBuffer()] : [Buffer.from(seed)];
  const [pda] = web3.PublicKey.findProgramAddressSync(seedBuffer, programId);
  return pda;
};

export const getPDAMulti = (
  programId: web3.PublicKey,
  user: web3.PublicKey,
  referral?: web3.PublicKey
) => {
  let solanaFarmVault = getPDA(programId, SOLANA_FARM_VAULT);
  let userPda = getPDA(programId, SOLANA_FARM_USER_PDA, user);
  let refPda = referral ? getPDA(programId, SOLANA_FARM_USER_PDA, referral) : null;

  return {
    userPda,
    refPda,
    solanaFarmVault
  };
};

export const getLamports = async (programProvider: AnchorProvider, user: web3.PublicKey) => {
  return await programProvider.connection.getBalance(user);
};

export const requestAirdropMulti = async (
  programProvider: AnchorProvider,
  senders: web3.PublicKey[],
  lamports: number
) => {
  let unResolvedPromises = [] as Promise<string>[];
  senders.forEach((fa) => unResolvedPromises.push(requestAirdrop(fa, lamports, programProvider)));
  await Promise.all(unResolvedPromises);
};

export const requestAirdrop = async (
  fundAccount: web3.PublicKey,
  lamports: number,
  programProvider: AnchorProvider
): Promise<string> => {
  const airdropTx = await programProvider.connection.requestAirdrop(fundAccount, lamports);
  const { blockhash, lastValidBlockHeight } = await programProvider.connection.getLatestBlockhash();

  await programProvider.connection.confirmTransaction(
    {
      blockhash,
      lastValidBlockHeight,
      signature: airdropTx
    },
    'finalized'
  );
  return airdropTx;
};

export const initialize = async (
  program: Program<SolanaFarm>,
  signers: web3.Keypair[],
  owner: web3.PublicKey
): Promise<string> => {
  return await program.methods
    .initialize()
    .accounts({
      solanaFarm: signers[0].publicKey,
      owner,
      // its by default
      systemProgram: anchor.web3.SystemProgram.programId
    })
    .signers(signers)
    .rpc({ skipPreflight: true, commitment: 'finalized' });
};

export const initializeUser = async (
  program: Program<SolanaFarm>,
  user: web3.Keypair,
  userPda: web3.PublicKey,
  userAccount: web3.PublicKey
) => {
  const tx = program.methods.initializeUser().accounts({
    userPda,
    user: user.publicKey,
    userAccount,
    systemProgram: anchor.web3.SystemProgram.programId
  });
  return await tx.instruction();
};

export const buyEggs = async (
  program: Program<SolanaFarm>,
  solValue: BN,
  signers: web3.Keypair[],
  solanaFarmPubkey: web3.PublicKey,
  devSystemAc: web3.PublicKey,
  referral?: web3.PublicKey,
  sendWithFakePda?: boolean
) => {
  let user = signers[0];
  // user pda
  let { solanaFarmVault, userPda, refPda } = getPDAMulti(
    program.programId,
    user.publicKey,
    referral
  );

  let itx = [] as web3.TransactionInstruction[];

  // initialize the user pda
  const userPdaInfo = await program.provider.connection.getAccountInfo(userPda);
  if (userPdaInfo === null) {
    const userPdaItx = await initializeUser(program, user, userPda, user.publicKey);
    itx.push(userPdaItx);
  }

  // check for ref pda
  if (refPda !== null) {
    const refPdaInfo = await program.provider.connection.getAccountInfo(refPda);
    if (refPdaInfo === null) {
      const refPdaItx = await initializeUser(program, user, refPda, referral);
      itx.push(refPdaItx);
    }
  }

  userPda = sendWithFakePda === true ? refPda : userPda;

  let tx = program.methods.buyEggs(solValue).accounts({
    solanaFarm: solanaFarmPubkey,
    solanaFarmVault,
    userPda,
    refPda,
    user: user.publicKey,
    dev: devSystemAc,
    systemProgram: anchor.web3.SystemProgram.programId
  });

  itx.push(await tx.instruction());
  let buyTransaction = new web3.Transaction().add(...itx);

  return await web3.sendAndConfirmTransaction(
    program.provider.connection,
    buyTransaction,
    signers,
    {
      commitment: 'finalized',
      skipPreflight: true
    }
  );
};

export const hatchEggs = async (
  program: Program<SolanaFarm>,
  signers: web3.Keypair[],
  solanaFarm: web3.PublicKey,
  refId?: web3.PublicKey
) => {
  let user = signers[0].publicKey;
  let { userPda, refPda } = getPDAMulti(program.programId, user, refId);
  let tx = await program.methods
    .hatchEggs()
    .accounts({
      solanaFarm,
      userPda,
      refPda,
      user,
      systemProgram: anchor.web3.SystemProgram.programId
    })
    .signers(signers)
    .transaction();

  return await web3.sendAndConfirmTransaction(program.provider.connection, tx, signers, {
    commitment: 'max',
    skipPreflight: true
  });
};

export const sellEggs = async (
  program: Program<SolanaFarm>,
  signers: web3.Keypair[],
  devSystem: web3.PublicKey,
  solanaFarm: web3.PublicKey
) => {
  // accounts
  let user = signers[0].publicKey;

  let { solanaFarmVault, userPda } = getPDAMulti(program.programId, user);
  let tx = await program.methods
    .sellEggs()
    .accounts({
      solanaFarm,
      solanaFarmVault,
      userPda,
      user,
      dev: devSystem,
      systemProgram: anchor.web3.SystemProgram.programId
    })
    .signers(signers)
    .transaction();

  return await web3.sendAndConfirmTransaction(program.provider.connection, tx, signers, {
    commitment: 'max',
    skipPreflight: true
  });
};

export const recoverSol = async (program: Program<SolanaFarm>, signer?: web3.Keypair) => {
  const solanaFarmVault = getPDA(program.programId, SOLANA_FARM_VAULT);
  let signers = signer ? [signer] : [];

  return await program.methods
    .recoverSol()
    .accounts({
      solanaFarmVault,
      owner: signer?.publicKey ?? program.provider.publicKey,
      systemProgram: anchor.web3.SystemProgram.programId
    })
    .signers(signers)
    .rpc({
      skipPreflight: true,
      commitment: 'finalized'
    });
};

// solana farm state
export const getSolanaFarmState = async (
  program: Program<SolanaFarm>,
  solanaFarm: web3.PublicKey
) => {
  return await program.account.solanaFarm.fetch(solanaFarm);
};

// returns user pda state
export const getUserAccountState = async (program: Program<SolanaFarm>, user: web3.PublicKey) => {
  let userPda = getPDA(program.programId, SOLANA_FARM_USER_PDA, user);
  return (await program.account.user.fetch(userPda)).userState;
};

export const getEarnedSFarm = async (
  program: Program<SolanaFarm>,
  solanaFarm: web3.PublicKey,
  user: web3.PublicKey
) => {
  let userPda = getPDA(program.programId, SOLANA_FARM_USER_PDA, user);
  let solanaFarmVault = getPDA(program.programId, SOLANA_FARM_VAULT);

  return (await program.methods
    .getAccumulatedSol()
    .accounts({
      userPda,
      solanaFarm,
      solanaFarmVault
    })
    .view({ skipPreflight: true })) as BN;
};

export const getMyEggs = async (program: Program<SolanaFarm>, user: web3.PublicKey) => {
  let userPda = getPDA(program.programId, SOLANA_FARM_USER_PDA, user);

  return (await program.methods
    .getMyEggs()
    .accounts({
      userPda
    })
    .view({ skipPreflight: true })) as BN;
};
