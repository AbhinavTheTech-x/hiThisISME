use anchor_lang::prelude::*;

#[error_code]
pub enum SolanaFarmError {
  #[msg("UnAuthorized Access")]
  UnAuthorizedAccess,

  #[msg("Invariant Vault Balance")]
  InvariantVaultBalance,

  #[msg("Not A Dev Pubkey")]
  NotDevPubKey,

  #[msg("User Already Initialized")]
  UserAlreadyInitialized,

  #[msg("Invalid Solana Farm Pubkey")]
  InvalidSolanaFarm,

  #[msg("Invalid PDA Owner Pubkey")]
  InvalidPDAOwner,

  #[msg("Invalid PDA")]
  InvalidPDA,

  #[msg("Self Referral Not Allowed")]
  SelfReferralNotAllowed
}