use solana_program::{pubkey, pubkey::Pubkey};

// Solana Farm PubKey
pub const SOLANA_FARM_PUB_KEY: Pubkey = pubkey!("E66zG3RmYjYUJQm5N5uSPiHqzNrsaBkDDgYPk5ngKRiS");

// Owner PubKey
pub const OWNER_PUB_KEY: Pubkey = pubkey!("2xLrdGsJwBKvucspaxbZ5YuvnSoWHMFwZEZgz8NqbjZL");

// Dev Pubkey
pub const DEV_PUB_KEY: Pubkey = pubkey!("DBrjeBc3zSNmBEPwhiQsfbpJjTRDRyd4zsTk4umSEntz");

// Program PubKey
pub const PROGRAM_PUB_KEY: Pubkey = pubkey!("2mLwsLjyi1qWR9KQrsRQERKB3PJbw6tnd1gcVtBwy85A");
