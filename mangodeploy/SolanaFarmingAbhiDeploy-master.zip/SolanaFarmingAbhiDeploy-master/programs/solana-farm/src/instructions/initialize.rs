use anchor_lang::prelude::*;
use crate::state::SolanaFarm;
use crate::errors::SolanaFarmError;
use crate::constants::{SOLANA_FARM_PUB_KEY,OWNER_PUB_KEY};

pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
    let solana_farm = &mut ctx.accounts.solana_farm;
    solana_farm.seed_market()
}

#[derive(Accounts)]
pub struct Initialize<'info> {
    // The data account of solana farm
    #[account(init,signer,payer = owner, space = SolanaFarm::MAX_SIZE, address = SOLANA_FARM_PUB_KEY @ SolanaFarmError::InvalidSolanaFarm)]
    pub solana_farm: Account<'info, SolanaFarm>,

    // The owner
    #[account(mut, signer, address = OWNER_PUB_KEY @ SolanaFarmError::UnAuthorizedAccess)]
    pub owner: Signer<'info>, 

    // The system program
    pub system_program: Program<'info, System>
}
